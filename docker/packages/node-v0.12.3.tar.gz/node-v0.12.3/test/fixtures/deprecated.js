require('util').p('This is deprecated');
